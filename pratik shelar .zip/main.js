let display = document.getElementById('display');
let buttons = document.querySelectorAll('button');
let answer = '';
let currentInput = '';

buttons.forEach(button => {
    button.addEventListener('click', () => {
        let value = button.textContent;

        if (value === '=') {
            try {
                answer = eval(currentInput);
                display.value = answer;
                currentInput = answer.toString();
            } catch {
                display.value = 'Error';
                currentInput = '';
            }
        } else if (value === 'AC') {
            currentInput = '';
            display.value = '';
        } else if (value === 'DEL') {
            currentInput = currentInput.slice(0, -1);
            display.value = currentInput;
        } else if (value === 'Ans') {
            currentInput += answer;
            display.value = currentInput;
        } else {
            currentInput += value;
            display.value = currentInput;
        }
    });
});
console.log();

